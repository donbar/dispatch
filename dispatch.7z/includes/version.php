<?php
function version(){
	return '.2';
}
?>